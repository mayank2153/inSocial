import express from 'express';
import mongoose from 'mongoose';
import dotenv from "dotenv";
import ConnectDB from './config/db.js';
import { app } from './app.js';
import serverless from "serverless-http";

dotenv.config({
  path: '.env'
});

ConnectDB()
  .then(() => {
    console.log('MongoDB connected successfully');
  })
  .catch((err) => {
    console.error("MONGO DB error: " + err);
  });

export const handler = serverless(app);
